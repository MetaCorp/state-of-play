//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import printing

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
    PrintingPlugin.register(with: registry.registrar(forPlugin: "PrintingPlugin"))
}
