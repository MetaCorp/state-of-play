#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/dad/Documents/Perso/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/dad/Documents/Perso/dart_pdf/printing"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_FRAMEWORK_DIR=/Users/dad/Documents/Perso/flutter/bin/cache/artifacts/engine/darwin-x64"
export "FLUTTER_BUILD_NAME=3.4.0"
export "FLUTTER_BUILD_NUMBER=3.4.0"
